// @TODO :
// Complétez ici le reducer afin qu'il puisse permettre d'ajouter et supprimer une todo du state
// …

export default function todoReducer(/* … */) {
    
    console.log('Action dispatched!', action.type, action.payload)

    // Votre code ici …
    
}
