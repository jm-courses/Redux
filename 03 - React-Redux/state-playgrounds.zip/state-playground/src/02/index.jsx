import React from 'react';

function ReduxApp() {
    return (
        <div style={{ margin: '1rem' }}>
            <h2>Redux</h2>
            <p>Micro-application de questionnaire</p>
        </div>
    );
}

export default ReduxApp;