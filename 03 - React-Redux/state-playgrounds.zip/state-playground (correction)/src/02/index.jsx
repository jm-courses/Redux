import React, { createRef, useEffect, useState } from 'react';

import store from './stores/questionsStore';

function ReduxApp() {
    const { questions } = store.getState();

    const inputRef = createRef();
    const [_, setQuestionsList] = useState(questions);

    useEffect(() => {
        store.subscribe(() => {
            setQuestionsList(store.getState().questions);
        });
    }, []);

    function addQuestion() {
        const questionText = inputRef.current.value;
        store.dispatch({ type: 'ADD_QUESTION', question: questionText });
        inputRef.current.value = '';
    }

    return (
        <div style={{ margin: '1rem' }}>
            <h2>Redux</h2>
            <p>Micro-application de questionnaire</p>

            {questions.map((question, index) => (
                <div key={index}>- {question}</div>
            ))}

            <input type="text" ref={inputRef} />
            <button onClick={addQuestion}>Ajouter une question</button>
        </div>
    );
}

// Pour le debug
window.store = store;

export default ReduxApp;