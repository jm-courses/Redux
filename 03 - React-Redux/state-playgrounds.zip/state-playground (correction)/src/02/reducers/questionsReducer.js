// Définition de la source de vérité
const initialState = {
    count : 0,
    questions : []
}

// Définition du Reducer
const questionsReducer = (state = initialState, action = {}) => {
    // Gestion des actions du Reducer
    switch(action.type){
        case 'ADD_QUESTION':
           // On doit retourner un nouveau state (sans toucher à la source de vérité)
            return { 
                ...state, 
                questions : state.questions.concat(action.question),
                count : state.count + 1
            };

        // Si aucun changement de state
        default:
            return state;
    }
}

export default questionsReducer;