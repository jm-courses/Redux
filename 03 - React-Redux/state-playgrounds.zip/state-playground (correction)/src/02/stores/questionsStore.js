import { createStore } from 'redux';

import questionsReducer from '../reducers/questionsReducer';

// Création du store avec le reducer
const store = createStore(questionsReducer);

// Log de l'état initial
console.log('state init', store.getState());

export default store;