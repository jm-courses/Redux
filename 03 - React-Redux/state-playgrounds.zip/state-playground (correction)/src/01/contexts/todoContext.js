// TODO:
// Créez ici un contexte nommé "TodoContext" et exportez-le

import { createContext } from 'react'

export const TodoContext = createContext();
