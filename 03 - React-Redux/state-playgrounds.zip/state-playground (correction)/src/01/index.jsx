import data from './data';

import React, { useReducer } from 'react';

import TodoList from './TodoList';
import FormAddTodo from './FormAddTodo';

// TODO: Importez ici le "todoReducer"
import todoReducer from './reducers/todoReducer';
// TODO: Importez ici le "TodoContext"
import { TodoContext } from './contexts/todoContext';

function ReducerApp() {

    // TODO: Utilisez ici le hook useReducer() avec le "todoReducer"
    const [state, dispatch] = useReducer(todoReducer, data);

    return (
        <div style={{ margin: '1rem' }}>
            {/* <pre>{JSON.stringify(state, null, 2)}</pre> */}

            {/* TODO: Enrobez ici les deux composant par le Provider du TodoContext,
            et passez comme valeur le 'state' et la fonction de 'dispatch' */}
            <TodoContext.Provider value={{state, dispatch}}>
                <TodoList todos={state} />
                <FormAddTodo />
            </TodoContext.Provider>
        </div>
    );

}

export default ReducerApp;